//package Networks;
//
//import java.util.List;
//
//
//import Drone.Drone;
//
//public interface Tower{
//	public void notifyTowerOfFailure();
//
//	public String getName();
//
//	public void sendHeartBeat(Drone drone, List<Tower> tower);
//}
