from django.db import models


class Notification(models.Model):

    class Meta:
        app_label = 'sam2017_app'


class Reminder(models.Model):

    class Meta:
        app_label = 'sam2017_app'

